import java.io.*;

/**
 * @author yzimero et tetienne
 * 
 */
public class SharedObject implements Serializable, SharedObject_itf {

	private static final long serialVersionUID = -6283958044849561365L;

	protected Object obj;

	// L'id du sharedObject
	private int id;
	// Enumération des différents états du verrou
	public enum Enum_lock {NL, RLC, WLC, RLT, WLT, RLT_WLC};

	// Le booléen qui permet d'attendre
	private boolean attente;

	// lock est l'état courant du verrou
	private Enum_lock lock;
	
	// // Définition de variables globales pour le verrou
	// private final static int NL = 0; 		// No Lock
	// private final static int RLC = 1; 		// Read Lock Cached
	// private final static int WLC = 2; 		// Write Lock Cached
	// private final static int RLT = 3; 		// Read Lock Taken
	// private final static int WLT = 4; 		// Write Lock Taken
	// private final static int RLT_WLC = 5; 	// Write Lock Taken - Write Lock
	// 									  	// Cached

	/**
	 * Le constructeur de  SharedObject
	 * @param id  l'identifiant du SharedObject
	 * @param object l'objet partagé
	 */
	public SharedObject(int id, Object object) {
		super();
		this.id = id;
		this.obj = object;
		this.lock = Enum_lock.NL;
		this.attente = false;
	}

	
	

	/**
	 * Verrouille en écriture l'objet partagé
	 */
	// public void lock_write() {
	// 	boolean maj = false;
	// 	// moniteur sur le sharedObject
	// 	synchronized (this) {
	// 		while (this.attente) {
	// 			try {
	// 				wait();
	// 			} catch (InterruptedException e) {
	// 				e.printStackTrace();
	// 			}
	// 		}
	// 		switch (this.lock) {
	// 		case NL:
	// 			maj = true;
	// 			this.lock = Enum_lock.WLT; 
	// 			break;

	// 		case RLC:
	// 			maj = true;
	// 			this.lock = Enum_lock.WLT; 
	// 			break;

	// 		case WLC:
	// 			this.lock = Enum_lock.WLT; break;

	// 		default:
	// 		System.err.println("problemfor lock_write");
	// 		System.err.println(lock);
	// 		break;
	// 		}
	// 	}
	// 	if (maj) {
	// 		this.obj = Client.lock_write(this.id);
	// 	}
	// }
	public void lock_write() {
		// Initialisation d'une variable locale qui sevira à demander la version
		// valide de l'objet au Server via le client.
		boolean demanderLockWrite = false;

		synchronized (this) {
			// Tant que l'attribut attente est vrai, on wait().
			while (this.attente) {
				try {
					wait();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}

			// Voir graphe des transitions entre les états
			switch (this.lock) {
			case NL:
				// Si on n'avait pas dans le cache l'objet valide, il faudra en
				// faire la demande via le client par la méthode lock_write(id).
				demanderLockWrite = true;

				this.lock = Enum_lock.WLT; // NL => WLT
				break;

			case RLC:
				demanderLockWrite = true;
				this.lock = Enum_lock.WLT; // RLC => WLT
				break;

			case WLC:
				this.lock = Enum_lock.WLT; // WLC => WLT
				break;

			default:
				break;
			}
		}

		// A la sortie, si le SharedObject était dans l'état NL on demande un
		// lock_write au client en lui passant l'id.
		if (demanderLockWrite) {
			this.obj = Client.lock_write(this.id);
		}
	}


	/**
	 * Verrouille en lecture l'objet partagé
	 * 
	 */
	public void lock_read() {
		boolean maj = false;
		// On synchronise sur l'objet pour éviter les problèmes de concurrence
		// CF système concurrent : moniteur 
		synchronized (this) {
			// Tant que l'attribut attente est vrai, on wait().
			while (this.attente) {
				try {
					wait();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			switch (this.lock) {
			// voir graphe des transitions entre les états
			case NL:
				maj = true;
				this.lock = Enum_lock.RLT; 
				break;

			case RLC:
				this.lock = Enum_lock.RLT; 
				break;

			case WLC:
				this.lock = Enum_lock.RLT_WLC; 
				break;

			default:
			System.err.println("problemfor lock_read");
			System.err.println(lock);
				break;
			}
		}
		if (maj) {
			
			this.obj = Client.lock_read(this.id);
		}
	}


	/**
	 * unlock : Déverouille le SharedObject
	 */
	public synchronized void unlock() {

		switch (this.lock) {

		case RLT:this.lock = Enum_lock.RLC; 
			break;
		case WLT:this.lock = Enum_lock.WLC; 
			break;
		case RLT_WLC: this.lock = Enum_lock.WLC;
			break;
		default:
		System.err.println("Unlock problem");
		System.out.println(lock);
			break;
		}
		try {
			notify(); // notifier les threads qui attendent
		} catch (Exception e) {

		}
	}


	/**
	 * Réduit le verrou 
	 * @return l'objet partagé
	 */
	
	public synchronized Object reduce_lock(){
		attente=true;
		while(lock == Enum_lock.WLT) {
			try {
				wait();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		switch (this.lock) {
			case WLC: this.lock = Enum_lock.RLC; break;
			case RLT_WLC: this.lock = Enum_lock.RLT;
			default : break;
		}
		attente=false;
		try {
			notify();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return obj;
}

	/**
	 * Invalide le verrou en lecture
	 */
	public synchronized void invalidate_reader() {
		this.attente = true; 
		while (this.lock == Enum_lock.RLT) {
			try {
				wait();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

		switch (this.lock) {
		
		case RLC: this.lock = Enum_lock.NL;break;
		default:
		break;
		}
		this.attente = false; 
		try {
			notify();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Invalide le SharedObject en écriture
	 * @return Object la dernière version de l'objet
	 */
	public synchronized Object invalidate_writer() {
			attente=true;
			while(lock ==Enum_lock.WLT|| lock == Enum_lock.RLT_WLC){
				try {
					wait();
				} catch (InterruptedException e) {}
			}
			switch (this.lock) {
			case WLC: this.lock = Enum_lock.NL; break;
			 
			default:
			 break;
			}
			attente=false;
			try {
				notify();
			} catch (Exception e) {
				e.printStackTrace();
			}
			return obj;
	}
	

/**
	 * Methode pour objetnir l'identifiant du SharedObject
	 * @return l'identifiant du SharedObject
	 */
	public int getId() {
		return this.id;
	}
}
