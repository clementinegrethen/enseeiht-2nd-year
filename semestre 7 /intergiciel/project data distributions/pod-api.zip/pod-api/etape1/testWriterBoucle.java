import java.util.Scanner;

public class testWriterBoucle {
    static String myName;
    static boolean flag = false;
    static SharedObject sentence;

    public static void main(String argv[]) {
        if (argv.length != 1) {
            System.out.println("java Irc <name>");
            return;
        }
        myName = argv[0];
        // initialize the system
        Client.init();
        // look up the IRC object in the name server
        // if not found, create it, and register it in the name server
        SharedObject s = Client.lookup("IRC");
        if (s == null) {
            s = Client.create(new Sentence());
            Client.register("IRC", s);
        }
        sentence = s;

        Scanner scanner = new Scanner(System.in);
        System.out.println("Press 's' to start writing and ' ' to stop");
        while (true) {
            String input = scanner.nextLine();
            if (input.equals("s")) {
                flag = true;
                new ActionWritterTerminal().start();
            } else if (input.equals(" ")) {
                flag = false;
            }
        }
    }
}

class ActionWritterTerminal extends Thread {

    @Override
    public void run() {
        int i = 0;
        while (testWriterBoucle.flag) {
            try {
                Thread.sleep(200);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            // lock the object in write mode
            testWriterBoucle.sentence.lock_write();

            // invoke the method
            ((Sentence) (testWriterBoucle.sentence.obj))
                    .write(testWriterBoucle.myName + " wrote " + i++);

            // unlock the object
            testWriterBoucle.sentence.unlock();
        }
    }
}
