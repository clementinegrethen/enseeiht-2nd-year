
import java.util.Scanner;

public class testNombreReader {

    private static final long serialVersionUID = 4392468196229185219L;
    static String myName;
    static SharedObject sentence;
    static boolean isReading = false;

    public static void main(String argv[]) throws Exception {

        if (argv.length != 1) {
            System.out.println("java Irc <name>");
            return;
        }
        myName = argv[0];
        // initialize the system
        Client.init();
        // look up the IRC object in the name server
        // if not found, create it, and register it in the name server
        sentence = Client.lookup("IRCNUM");
        if (sentence == null) {
            sentence = Client.create(new SentenceNumerique());
            Client.register("IRCNUM", sentence);
        }

        Scanner sc = new Scanner(System.in);
        System.out.println("Enter 'start' to begin reading or 'stop' to stop reading:");
        String input = sc.nextLine();
        while (!input.equals("stop")) {
            if (input.equals("start")) {
                isReading = true;
                new ActionReaderNumerique().start();
                input = sc.nextLine();
                while (isReading) {
                    if (System.in.available() > 0) {
                        if (System.in.read() == ' ') {
                            isReading = false;
                        }
                    }
                }
            }
            else {
                input = sc.nextLine();
            }
        }
    }
}

class ActionReaderNumerique extends Thread {

    @Override
    public void run() {
        while (testNombreReader.isReading) {
            try {
                sleep(200);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            // lock the object in read mode
            testNombreReader.sentence.lock_read();

            // invoke the method
            int s = ((SentenceNumerique) (testNombreReader.sentence.obj)).read();

            // unlock the object
            testNombreReader.sentence.unlock();

            // display the read value
            System.out.println(s);
        }
    }
}
