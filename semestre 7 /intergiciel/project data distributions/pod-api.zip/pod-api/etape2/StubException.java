public class StubException extends RuntimeException {

	// private static final long serialVersionUID = 1L;

	public StubException(String msg) {
		super(msg);
	}
	
	public StubException(String msg, Throwable e) {
		super(msg,e);
	}
}