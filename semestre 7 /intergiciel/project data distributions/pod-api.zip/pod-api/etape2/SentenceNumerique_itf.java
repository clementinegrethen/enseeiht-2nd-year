
public interface SentenceNumerique_itf extends SharedObject_itf {
	public void write(int nb, int op);
	public int read();
}