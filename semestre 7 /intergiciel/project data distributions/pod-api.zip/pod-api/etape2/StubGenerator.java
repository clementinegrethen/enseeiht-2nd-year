// import java.io.BufferedWriter;
// import java.io.File;
// import java.io.FileWriter;
// import java.io.IOException;
// import java.lang.reflect.Method;
// import java.lang.reflect.Modifier;
// import java.lang.reflect.Parameter;
// import java.rmi.RemoteException;

// import javax.tools.DiagnosticCollector;
// import javax.tools.JavaCompiler;
// import javax.tools.JavaFileObject;
// import javax.tools.StandardJavaFileManager;
// import javax.tools.ToolProvider;

// public class StubGenerator {
    
//     public StubGenerator() {

//     }

//     /**
//      * Génère un fichier stub et le compile
//      * Pour l'objet o
//      */
//     public static void generateStub(Object o) {
//         String name = o.getClass().getSimpleName();

//         /* On vérifie que le stub n'existe pas déjà */
//         String currentPath = System.getProperty("user.dir");
//         File currentFolder = new File(currentPath);
//         File[] files = currentFolder.listFiles();
//         boolean containsClass = false;
//         boolean containsJava = false;
//         for (File file : files) {
//             if (file.getName().equals(name+"_stub.class")) {
//                 containsClass = true;
//             }
//             if (file.getName().equals(name+"_stub.java")) {
//                 containsJava = true;
//             }
//         }
//         /* Si le fichier n'existe pas on le créé */
//         if (!containsJava) {
//             File stubFile = new File(name+"_stub.java");
//             try (BufferedWriter buff = new BufferedWriter(new FileWriter(stubFile))) {
//                 String text = "";
//                 text += "public class " + name + "_stub extends SharedObject implements ";
//                 text += name + "_itf, java.io.Serializable {\n\n";
//                 // text += "@author cgrethen_lweisbec";
//                 text += "\tpublic " + name + "_stub(Object o, int id) {\n";
//                 text += "\t\tsuper(id, o);\n\t}\n";

//                 Method[] methods = o.getClass().getDeclaredMethods();
//                 for (Method m : methods) {
//                     if (Modifier.isPrivate(m.getModifiers())) {
//                         text += "\t" + "public ";
//                     } else if (Modifier.isPublic(m.getModifiers())) {
//                         text += "\t" + "public ";
//                     } else if (Modifier.isProtected(m.getModifiers())) {
//                         text += "\t" + "public ";
//                     } // On pourrait rajouter : static, synchronized, ...

//                     text += m.getReturnType().getSimpleName() + " " + m.getName() + "(";

//                     int nbArg = 0;
//                     Class<?>[] parameters = m.getParameterTypes();
//                     for (Class<?> p : parameters) {
//                         text += p.getSimpleName() + " arg" + nbArg;
//                         if (nbArg != parameters.length - 1) {
//                             text += ", ";
//                         }
//                         nbArg++;
//                     }
//                     text += ")";

//                     Class<?>[] exceptions = m.getExceptionTypes();
//                     if (exceptions.length != 0) {
//                         text += " throws ";
//                     }
//                     int nbExc = 0;
//                     for (Class<?> e : exceptions) {
//                         text += e.getName();
//                         if (nbExc != exceptions.length - 1) {
//                             text += ", ";
//                         }
//                         nbExc++;
//                     }
//                     text += " {\n";

//                     char varName = Character.toLowerCase(name.charAt(0));
//                     text += "\t\t" + name + " " + varName + " = (" + name + ") obj;\n";
//                     String param = "";
//                     for (int i=0; i < nbArg; i++) {
//                         param += "arg" + i;
//                         if (i != nbArg-1) {
//                             param += ", ";
//                         }
//                     }
                    
//                     if (!m.getReturnType().getSimpleName().equals("void")) {
//                         text += "\t\treturn ";
//                     } else {
//                         text += "\t\t";
//                     }

//                     text += varName + "." + m.getName() +"(" + param +");\n"; 

//                     text += "\t}\n\n";
//                 }

//                 text += "}";

//                 buff.write(text);
//                 buff.close();
//             } catch (IOException e) {
//                 e.printStackTrace();
//             }
//         }

//         if (!containsClass) {
//             JavaCompiler compiler = ToolProvider.getSystemJavaCompiler();
//             int result = compiler.run(null, null, null, "-d", ".", name + "_stub.java");
//             if (result == 0) {
//                 System.out.println("Compilation réussie");
//             } else {
//                 System.out.println("La compilation a échoué");
//             }
//         }
//     }
// }



import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Method;
import javax.tools.JavaCompiler;
import javax.tools.JavaFileObject;
import javax.tools.StandardJavaFileManager;
import javax.tools.ToolProvider;
import java.util.Arrays;

public class StubGenerator {

    public static void generateStub(Object obj) throws IOException {
        String className = obj.getClass().getSimpleName();
        String currentPath = System.getProperty("user.dir");
        File currentFolder = new File(currentPath);
        File[] files = currentFolder.listFiles();

        boolean stubFileExists = Arrays.stream(files)
                                       .anyMatch(f -> f.getName().equals(className + "_stub.java"));

        if (!stubFileExists) {
            File stubFile = new File(className + "_stub.java");
            try (BufferedWriter bw = new BufferedWriter(new FileWriter(stubFile))) {
                StringBuilder fileContent = new StringBuilder();
                fileContent.append("public class " + className + "_stub extends SharedObject implements ");
                fileContent.append(className + "_itf, java.io.Serializable {\n\n");
                fileContent.append("\tpublic " + className + "_stub(Object o, int id) {\n");
                fileContent.append("\t\tsuper(id, o);\n\t}\n");

                Method[] methods = obj.getClass().getDeclaredMethods();
                for (Method method : methods) {
                    fileContent.append("\tpublic ");
                    fileContent.append(method.getReturnType().getSimpleName());
                    fileContent.append(" " + method.getName() + "(");

                    int nbArg = 0;
                    Class<?>[] parameters = method.getParameterTypes();
                    for (Class<?> param : parameters) {
                        fileContent.append(param.getSimpleName() + " arg" + nbArg);
                        if (nbArg != parameters.length - 1) {
                            fileContent.append(", ");
                        }
                        nbArg++;
                    }
                    fileContent.append(")");

                    Class<?>[] exceptions = method.getExceptionTypes();
                    if (exceptions.length != 0) {
                        fileContent.append(" throws ");
                    }
                    int nbExc = 0;
                    for (Class<?> exc : exceptions) {
                        fileContent.append(exc.getName());
                        if (nbExc != exceptions.length - 1) {
                            fileContent.append(", ");
                        }
                        nbExc++;
                    }
                    fileContent.append(" {\n");
                    char varName = Character.toLowerCase(className.charAt(0));
                    fileContent.append("\t\t" + className + " " + varName + " = (" + className + ") obj;\n");
                    String param = "";
                    for (int i=0; i < nbArg; i++) {
                        param += "arg" + i;
                        if (i != nbArg-1) {
                            param += ", ";
                        }
                    }
                    if (!method.getReturnType().getSimpleName().equals("void")) {
                        fileContent.append("\t\treturn ");
                    } else {
                        fileContent.append("\t\t");
                    }
                    fileContent.append(varName + "." + method.getName() +"(" + param +");\n");

                    fileContent.append("\t}\n");

                }
                fileContent.append("}");
                bw.write(fileContent.toString());
                
            } catch (IOException e) {
           
                e.printStackTrace();
            }
            // Compilation du code généré
            JavaCompiler compiler = ToolProvider.getSystemJavaCompiler();
            int result = compiler.run(null, null, null, "-d", ".", className + "_stub.java");
            if (result == 0) {
                System.out.println("Compilation réussie");
            } else {
                System.out.println("La compilation a échoué");
            }
            
            


        }
    }
}


