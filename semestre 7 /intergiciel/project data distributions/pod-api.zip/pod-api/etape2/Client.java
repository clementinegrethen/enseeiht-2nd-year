import java.rmi.*;
import java.rmi.server.UnicastRemoteObject;
import java.rmi.registry.*;
import java.net.*;
import java.util.HashMap;
import java.net.*;
import java.lang.reflect.Constructor;
import java.rmi.*;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
import java.util.HashMap;
import java.rmi.registry.*;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.net.*;



// COdé avec le truc de gaven : à modifier un peu surtout init et l'ajout des stub mais ça va 
// attetntion à la classe stubgenerator 

public class Client extends UnicastRemoteObject implements Client_itf {

	private static final long serialVersionUID = 5838449924074267286L;
// client    
	private static Client_itf instance = null;
// serveur 
	private static Server_itf server;
// hashmap des objets du client 
	private static HashMap<Integer, SharedObject> local_shared_objects;
	private static boolean deja_initialise=false;


	public Client() throws RemoteException {
		super();
	}

///////////////////////////////////////////////////
//         Interface to be used by applications
///////////////////////////////////////////////////
	// initialization of the client layer
	public static void init() {
		if (Client.instance == null) {
			try {
				Client.instance = new Client();
				server = (Server_itf) Naming.lookup("//localhost:9000/server");
				local_shared_objects = new HashMap<Integer,SharedObject>();
			} catch (RemoteException | MalformedURLException | NotBoundException e) {
				e.printStackTrace();
			}
		}
	}
	
/**
	 * Récupère l'objet partagé enregistré sous le nom "name"
	 * @param name le nom de l'objet partagé recherché sur le serveur
	 * @return SharedObject le SharedObject trouvé, null si non trouvé
	 */	public static SharedObject lookup(String name) {
		SharedObject objet_recupere = null;
		int id = -1;
		try{

			// On récupère l'id de l'objet partagé
		  id=server.lookup(name);
		 if (id==-1){
			 return null;
		 }
		            Object obj = server.lock_read(id, instance);
					// On génère le stub de l'objet partagé et on l'enregistre dans la hashmap
					// le stub permet de faire des appels distants sur l'objet partagé
					StubGenerator.generateStub(obj);
					String className = obj.getClass().getSimpleName() + "_stub";
					Class<?> classe = Class.forName(className);
					Constructor<?> cons = classe.getConstructor(new Class[] {Object.class, int.class});
					SharedObject object = (SharedObject) cons.newInstance(null, id);
					local_shared_objects.put(id, object);
					return object;

		 } catch (Exception e) {
			e.printStackTrace();
		 }
		 return objet_recupere;
		 
	}		
	
	// Enregistremet du sharedObject so sur le serveur
	public static void register(String name, SharedObject_itf objet_enregistre) {
		try{

		server.register(name,((SharedObject) objet_enregistre).getId());
		} catch (RemoteException e) {
			e.printStackTrace();
		}
	}
	// creation of a shared object
	public static SharedObject create(Object objet_creation) {
		try {
			int id_objet= server.create(objet_creation);
			StubGenerator.generateStub(objet_creation);
			String className = objet_creation.getClass().getSimpleName() + "_stub";
			Class<?> classe = Class.forName(className);
			Constructor<?> cons = classe.getConstructor(new Class[] {Object.class, int.class});
			SharedObject object = (SharedObject) cons.newInstance(objet_creation, id_objet);
			local_shared_objects.put(id_objet, object);
			return object;
			

		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	
/////////////////////////////////////////////////////////////
//    Interface to be used by the consistency protocol
////////////////////////////////////////////////////////////

	// request a read lock from the server
	// On vérouille l'objet correspondant à l'id
	// On le vérouille en lecture et on le retourne
	public static Object lock_read(int id) {
		Object o = null;
		try {
			 o = server.lock_read(id, instance);
			return o;
		}	catch (Exception e) {
			e.printStackTrace();
		}
		return o;

	}

	// request a write lock from the server
	public static Object lock_write (int id) {
		Object o = null;
		try {
			 o = server.lock_write(id, instance);
			return o;
		}	catch (Exception e) {
			e.printStackTrace();
		}
		return o;
	}

	// receive a lock reduction request from the server
	public Object reduce_lock(int id) throws java.rmi.RemoteException {
		return local_shared_objects.get(id).reduce_lock();

	}


	// receive a reader invalidation request from the server
	public void invalidate_reader(int id) throws java.rmi.RemoteException {
		local_shared_objects.get(id).invalidate_reader();

	}


	// receive a writer invalidation request from the server
	public Object invalidate_writer(int id) throws java.rmi.RemoteException {
		return local_shared_objects.get(id).invalidate_writer(); 

	}
}

